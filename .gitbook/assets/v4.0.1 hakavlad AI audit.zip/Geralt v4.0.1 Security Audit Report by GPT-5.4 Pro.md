# Geralt v4.0.1 Security Audit Report by GPT-5.4 Pro (2026-04-18)

## Prompt

Perform a security audit of the Geralt library code.
Assess any discovered vulnerabilities using the Common Vulnerability Scoring System (CVSS).
Propose remediation for identified vulnerabilities, if any.
Provide a detailed report.

---

# Security Audit Report: Geralt 4.0.1

## Executive summary

I reviewed the provided Geralt source code as a **static security audit** of the wrapper/API layer around libsodium.

### Overall assessment

- **Good news:** I did **not** find evidence of catastrophic cryptographic implementation flaws in the reviewed primitives. Geralt mostly delegates core crypto to libsodium, validates buffer sizes aggressively, and has strong test coverage with RFC / Wycheproof / KAT vectors.
- **Primary risks found:** I identified **two concrete security issues** in the wrapper/API layer:
  1. **Improper Unicode-to-byte narrowing in text parsing APIs** (`Encodings`, `Argon2id`) that can accept non-ASCII input as valid encoded data.
  2. **Incorrect native return type for Base64 length calculation**, which can mis-size buffers for very large inputs and produce a denial of service.

I also found several **hardening issues** worth fixing, especially around mutable string wiping, authenticated-decryption buffer hygiene, and misuse-resistant API design.

---

## Scope reviewed

Reviewed files include:

- Crypto wrappers: `AEGIS128L`, `AEGIS256`, `Argon2id`, `BLAKE2b`, `ChaCha20`, `ChaCha20Poly1305`, `Ed25519`, `HChaCha20`, `Poly1305`, `X25519`, `XChaCha20`, `XChaCha20Poly1305`
- Stateful/incremental APIs
- Helper APIs: `Encodings`, `SecureMemory`, `SecureRandom`, `ConstantTime`, `GuardedHeapAllocation`, `Iso78164Padding`, `Validation`
- Native interop declarations and initialization logic
- Unit tests

---

## Findings summary

| ID | Title | Severity | CVSS v3.1 |
|---|---|---:|---:|
| GRT-001 | Non-ASCII input can be accepted by text-decoding APIs due to lossy `char -> byte` casts | **Medium** | **5.3** |
| GRT-002 | Base64 encoded-length interop uses `int` instead of native-sized type, enabling overflow/DoS on huge inputs | **Low** | **3.3** |

---

# Detailed findings

## GRT-001 — Non-ASCII input accepted by decoding/parsing APIs

### Affected code

- `Encodings.FromHex`
- `Encodings.FromBase64`
- `Argon2id.VerifyHash`
- `Argon2id.NeedsRehash`

### Evidence

Examples:

```csharp
hexBuffer[i] = (byte)hex[i];
```

```csharp
base64Buffer[i] = (byte)base64[i];
```

```csharp
hashBytes[i] = (byte)hash[i];
```

These APIs accept `ReadOnlySpan<char>` input, but they convert each UTF-16 `char` to a single `byte` by truncation.

### Why this is a security problem

This is a **canonicalization / input-validation flaw**.

A non-ASCII Unicode character with low byte matching an ASCII character will be silently transformed into that ASCII byte. That means Geralt can accept text that is **not valid ASCII hex/Base64/PHC**, but still parse it as if it were.

Examples of the class of problem:

- A Unicode character whose code point ends in `0x30` becomes ASCII `'0'`
- One ending in `0x41` becomes ASCII `'A'`
- One ending in `0x3D` becomes ASCII `'='`

So a caller expecting “strict ASCII hex/Base64/PHC string only” can unknowingly accept alternate Unicode spellings that decode to the same bytes.

### Impact

This can enable:

- **Input validation bypass**
- **Log/audit mismatch** (stored/displayed text differs from parsed bytes)
- **Canonicalization confusion** in protocols or applications that treat ASCII encoding as security-sensitive
- Potential policy bypass if upstream validation assumes “non-ASCII will be rejected by the decoder”

This is especially relevant for:

- token parsing
- key material import/export
- signature or MAC inputs carried as text
- password-hash string handling (`Argon2id.VerifyHash`, `NeedsRehash`)

### CVSS assessment

**CVSS v3.1:** `AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:L/A:N`  
**Score:** **5.3 (Medium)**

### Remediation

Reject non-ASCII input before narrowing to bytes.

#### Recommended fix pattern

```csharp
for (int i = 0; i < hex.Length; i++)
{
    char c = hex[i];
    if (c > 0x7F)
    {
        throw new FormatException("Input must contain only ASCII characters.");
    }
    hexBuffer[i] = (byte)c;
}
```

Apply the same approach to:

- `Encodings.FromHex`
- `Encodings.FromBase64`
- `Argon2id.VerifyHash`
- `Argon2id.NeedsRehash`

### Recommended tests

Add regression tests that ensure the following are rejected:

- non-ASCII chars that truncate to valid hex digits
- non-ASCII chars that truncate to valid Base64 alphabet characters
- non-ASCII chars inside Argon2 PHC strings

---

## GRT-002 — Base64 encoded-length interop uses wrong return type

### Affected code

`Interop.Encodings.cs`

```csharp
[LibraryImport(DllName)]
[UnmanagedCallConv(CallConvs = [typeof(CallConvCdecl)])]
internal static partial int sodium_base64_encoded_len(nuint binaryLength, int variant);
```

Used by:

```csharp
public static int GetToBase64BufferSize(ReadOnlySpan<byte> data, Base64Variant variant = Base64Variant.Original)
{
    Validation.NotEmpty(nameof(data), data.Length);
    return sodium_base64_encoded_len((nuint)data.Length, (int)variant) - 1;
}
```

### Why this is a security problem

The native libsodium function returns a **native-sized length** (`size_t`), but Geralt declares it as `int`.

For very large inputs, the returned length can exceed `Int32.MaxValue`. That can lead to:

- truncated/overflowed size calculation
- incorrect output buffer sizing
- subsequent conversion failure
- potential libsodium misuse-handler invocation / process termination

### Practical impact

This is a **denial-of-service** issue on very large inputs.

Because these APIs are span-based, exploitation generally requires the process already to be handling very large in-memory buffers, so the issue is lower severity than GRT-001.

### CVSS assessment

**CVSS v3.1:** `AV:L/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L`  
**Score:** **3.3 (Low)**

> In a network-facing service that Base64-encodes attacker-controlled multi-GB payloads, the practical availability risk could be higher.

### Remediation

Use a native-sized return type and perform a checked conversion to `int`.

#### Recommended fix

```csharp
[LibraryImport(DllName)]
[UnmanagedCallConv(CallConvs = [typeof(CallConvCdecl)])]
internal static partial nuint sodium_base64_encoded_len(nuint binaryLength, int variant);
```

Then:

```csharp
public static int GetToBase64BufferSize(ReadOnlySpan<byte> data, Base64Variant variant = Base64Variant.Original)
{
    Validation.NotEmpty(nameof(data), data.Length);
    nuint encodedLen = sodium_base64_encoded_len((nuint)data.Length, (int)variant);
    return checked((int)encodedLen - 1);
}
```

Also consider explicitly rejecting inputs above the largest safely encodable managed size.

### Recommended tests

Boundary tests around the largest supported input size for Base64 sizing logic.

---

# Hardening issues / security recommendations

These are important, but I would treat them as **security hardening items** rather than scored vulnerabilities in isolation.

---

## H-001 — `SecureMemory.ZeroMemory(ReadOnlySpan<char>)` can mutate immutable/shared strings

### Evidence

```csharp
public static unsafe void ZeroMemory(ReadOnlySpan<char> buffer)
{
    fixed (char* b = buffer) {
        sodium_memzero(new IntPtr(b), (nuint)buffer.Length * sizeof(char));
    }
}
```

### Risk

Because the API accepts `ReadOnlySpan<char>`, callers can pass spans over **immutable strings**, including interned/shared strings. That can:

- corrupt shared process state
- break assumptions about string immutability
- crash on some runtimes/platforms if memory is read-only

### Recommendation

Prefer one of:

- remove this overload
- change it to `Span<char>` only
- document very explicitly that callers must **not** pass string-backed spans

---

## H-002 — Authenticated decryption APIs do not clear destination buffers on verification failure

Affected patterns include:

- `AEGIS128L.Decrypt`
- `AEGIS256.Decrypt`
- `ChaCha20Poly1305.Decrypt`
- `XChaCha20Poly1305.Decrypt`
- `IncrementalXChaCha20Poly1305.DecryptChunk`

### Risk

On auth failure, these methods throw, but they do **not** explicitly zero the output buffer. If the caller reuses a buffer containing prior plaintext, stale data may remain.

### Recommendation

On failure, explicitly zero the destination span before throwing:

```csharp
if (ret != 0)
{
    SecureMemory.ZeroMemory(plaintext);
    throw new CryptographicException(...);
}
```

---

## H-003 — `IncrementalXChaCha20Poly1305` relies on caller to enforce `Final` chunk semantics

This mirrors libsodium semantics, but it is easy for callers to decrypt chunks and forget to verify that the stream ended with `ChunkFlag.Final`.

### Risk

If the application ignores the returned flag, **truncation attacks** can become possible.

### Recommendation

Consider:

- stronger documentation
- an `IsFinalized`/`SeenFinal` property
- or a higher-level helper that refuses to accept a stream unless `Final` was observed

---

## H-004 — Argon2 hash verification has no policy cap for attacker-controlled PHC strings

`Argon2id.VerifyHash` passes PHC strings directly to libsodium verification. If a deployment ever verifies **untrusted** PHC strings, cost parameters in the PHC string can become a CPU/memory DoS vector.

### Recommendation

Offer a bounded variant, e.g.:

- `VerifyHash(hash, password, maxIterations, maxMemorySize)`

---

## H-005 — Exact libsodium point-release pinning may slow patch adoption

Geralt enforces:

```csharp
if (pointRelease != SODIUM_VERSION_STRING) {
    throw new NotSupportedException(...)
}
```

with `SODIUM_VERSION_STRING = "1.0.21"`.

### Risk

If a compatible future libsodium patch release ships security fixes, Geralt will reject it until Geralt itself is updated.

### Recommendation

If ABI compatibility is guaranteed for a release family, consider allowing compatible patch versions rather than requiring an exact point release.

---

# Positive security observations

The codebase has several strong points:

- **Uses libsodium** for cryptographic primitives instead of custom crypto
- **Extensive known-answer/vector tests**, including RFC and Wycheproof coverage
- **Good size validation** on almost all public APIs
- **State zeroization** is present in many sensitive paths
- `X25519.ComputeSharedSecret` correctly relies on libsodium to reject invalid/low-order public keys
- Constant-time comparisons are used where appropriate

---

# Remediation priority

## Fix first
1. **GRT-001** — strict ASCII validation before any `char -> byte` conversion
2. **GRT-002** — correct `sodium_base64_encoded_len` interop signature

## Then harden
3. Restrict or redesign `SecureMemory.ZeroMemory(ReadOnlySpan<char>)`
4. Zero destination buffers on auth failure
5. Add guidance / helpers for secretstream `Final` enforcement
6. Consider bounded Argon2 verification overloads

---

# Conclusion

**Bottom line:** Geralt’s reviewed crypto wrappers are generally well-structured and benefit from libsodium’s proven primitives, but I found **two real wrapper-layer security issues**:

- a **Medium** severity text canonicalization flaw in multiple char-based parsing APIs
- a **Low** severity Base64 sizing interop bug affecting huge inputs

These are fixable without redesigning the library.

If you want, I can next produce a **patch-oriented remediation plan** with concrete code changes per file.