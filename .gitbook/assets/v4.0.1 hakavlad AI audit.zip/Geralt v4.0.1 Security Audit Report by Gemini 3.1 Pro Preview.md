# Geralt v4.0.1 Security Audit Report by Gemini 3.1 Pro Preview (2026-04-18)

## Prompt

Perform a security audit of the Geralt library code.
Assess any discovered vulnerabilities using the Common Vulnerability Scoring System (CVSS).
Propose remediation for identified vulnerabilities, if any.
Provide a detailed report.

---

Here is the detailed security audit report for the Geralt cryptographic library.

# Security Audit Report: Geralt Library

## Executive Summary
A comprehensive security audit of the Geralt library source code was conducted to identify security vulnerabilities, improper API usages, and design flaws. The audit identified two significant Out-of-Bounds (OOB) Read vulnerabilities that could lead to Denial of Service (DoS) or memory exposure, one issue resulting in the exposure of sensitive cryptographic state to the managed Garbage Collector (GC) heap, and one missing hardware compatibility check leading to potential application crashes. 

All discovered vulnerabilities have been assessed using the Common Vulnerability Scoring System (CVSS v3.1) and are detailed below with proposed remediations.

---

## Vulnerability Findings

### 1. Out-of-Bounds Read in Argon2id Hash Verification
**Severity:** High<br>
**CVSS v3.1 Score:** 8.2 (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:H)<br>
**Affected File:** `Argon2id.cs` (`VerifyHash` and `NeedsRehash` methods)

**Description:**<br>
The `VerifyHash` and `NeedsRehash` methods allocate a stack buffer (`hashBytes`) of exactly `HashSize` (128 bytes) to copy the provided managed string hash into a UTF-8 byte array. If the user-provided `hash` is exactly 128 characters long, the buffer is completely filled, leaving no room for a null terminator (`\0`). 
Libsodium's underlying functions (`crypto_pwhash_argon2id_str_verify` and `crypto_pwhash_argon2id_str_needs_rehash`) expect a null-terminated string and internally call `strlen()`. Passing a non-null-terminated 128-byte buffer causes `strlen()` to read past the end of the stack allocation. This out-of-bounds read can cause an Access Violation (crashing the application/service) or potentially leak adjacent stack memory.

**Remediation:**<br>
Allocate `HashSize + 1` bytes for the `hashBytes` buffer to guarantee that the last byte is always a null terminator.
```csharp
Span<byte> hashBytes = stackalloc byte[HashSize + 1]; 
hashBytes.Clear();
```

### 2. Out-of-Bounds Read in HChaCha20 Key Derivation
**Severity:** Medium<br>
**CVSS v3.1 Score:** 5.3 (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:L)<br>
**Affected File:** `HChaCha20.cs` (`DeriveKey` method)

**Description:**<br>
The `HChaCha20.DeriveKey` method accepts an optional `personalization` span. If the user passes an empty array (`new byte[0]`), its length is 0, which bypasses the exact length validation (`if (personalization.Length != 0)`). 
In .NET, marshaling a zero-length span that is backed by an array results in a non-null pointer pointing to the array's memory location. Libsodium's `crypto_core_hchacha20` function checks whether the personalization pointer is `NULL`; because it receives a non-null pointer, it assumes the presence of a 16-byte constant and reads 16 bytes. This results in an out-of-bounds read from the .NET heap, which could mix garbage memory into the derived key or cause a crash.

**Remediation:**<br>
Explicitly pass a null pointer (via `default`) to libsodium when the personalization span is empty.
```csharp
int ret = crypto_core_hchacha20(outputKeyingMaterial, nonce, inputKeyingMaterial, personalization.Length == 0 ? default : personalization);
```

### 3. Sensitive Cryptographic State Exposure via GC Relocation
**Severity:** Low / Medium<br>
**CVSS v3.1 Score:** 4.0 (CVSS:3.1/AV:L/AC:L/PR:H/UI:N/S:U/C:L/I:N/A:N)<br>
**Affected Files:** `IncrementalBLAKE2b.cs`, `IncrementalEd25519ph.cs`, `IncrementalPoly1305.cs`, `IncrementalXChaCha20Poly1305.cs`

**Description:**<br>
In the incremental cryptographic classes, the author attempts to pin the unmanaged state struct using `GCHandle.Alloc(_state, GCHandleType.Pinned)`. However, because `_state` is a value type (struct), `GCHandle.Alloc` boxes a *copy* of the struct onto the heap and pins the copy, leaving the actual `_state` field inside the class unpinned. 
The Garbage Collector (GC) is free to relocate the class instance during heap compaction. When the object is relocated, old copies of the sensitive cryptographic state (which can include keys and subkeys) are left behind in un-zeroed memory. Consequently, the `SecureMemory.ZeroMemory` call in the `Dispose` method only zeroes the *current* location of the object, failing to clear the ghost copies left by the GC.

**Remediation:**<br>
Do not rely on `GCHandle.Alloc` to pin struct fields of a managed class. Instead, allocate the cryptographic state in unmanaged memory using `sodium_malloc` (wrapped safely) or `NativeMemory.Alloc`, and access it via pointers. Alternatively, store the state inside a pinned `byte[]` array.

### 4. Missing Hardware Support Check for AEGIS Algorithms
**Severity:** Low (Denial of Service / Bug)<br>
**CVSS v3.1 Score:** 3.3 (CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:L)<br>
**Affected Files:** `AEGIS128L.cs`, `AEGIS256.cs`

**Description:**<br>
The AEGIS-128L and AEGIS-256 algorithms require specific hardware acceleration instructions (AES-NI on x86/x64, ARM Crypto Extensions on ARM). Libsodium mandates that developers check for hardware support before invoking these functions. The `AEGIS128L.Encrypt/Decrypt` and `AEGIS256.Encrypt/Decrypt` methods blindly call the libsodium functions without checking for CPU support. If the library is deployed on older hardware or certain ARM processors lacking these extensions, the application will crash abruptly with an illegal instruction exception.

**Remediation:**<br>
Import the hardware check functions from libsodium and validate support before proceeding:
```csharp
[LibraryImport(DllName)]
[UnmanagedCallConv(CallConvs = [typeof(CallConvCdecl)])]
internal static partial int crypto_aead_aegis128l_is_available();
// ...
if (crypto_aead_aegis128l_is_available() == 0) {
    throw new PlatformNotSupportedException("AEGIS-128L is not supported on this CPU.");
}
```

---

## Conclusion
The Geralt library offers a clean and mostly well-validated wrapper around libsodium. However, the interactions between .NET's memory management (Stack/Heap/Span marshaling) and C-based unmanaged code introduced subtle but critical vulnerabilities. Addressing the missing null-terminators for `Argon2id` limits severe DoS vectors, while fixing the state pinning logic ensures that Geralt meets its promise of securely wiping sensitive cryptographic material from memory.