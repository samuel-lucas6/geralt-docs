# Geralt v4.2.0 Security Audit Report by Claude 4.7 Opus (2026-05-25)

## Prompt

Conduct a security audit of the Geralt library code.
Assess any discovered vulnerabilities using the Common Vulnerability Scoring System (CVSS).
Propose remediation for identified vulnerabilities, if any.
Provide a detailed report.

---

 Security Audit Report: Geralt Cryptographic Library

**Library:** Geralt v4.2.0<br>
**Author:** Samuel Lucas<br>
**Description:** A modern cryptographic library for .NET 8+ based on libsodium and inspired by Monocypher<br>
**Audit Date:** 2026-05-25<br>
**Auditor scope:** Source code review of the supplied files (managed C# wrapper code over libsodium native primitives), with CVSS v3.1 scoring of identified findings.

---

## 1. Executive Summary

Geralt is a thin, well-designed managed wrapper around `libsodium`, which itself is a vetted, audited cryptographic library. The vast majority of the security-critical work (the actual primitives: AEGIS, ChaCha20-Poly1305, BLAKE2b, Argon2id, X25519, Ed25519, Poly1305, etc.) is delegated to native libsodium functions. Geralt's responsibilities are limited to:

- Input validation (lengths, ranges).
- Memory hygiene (zeroing buffers, guarded heap allocations).
- API ergonomics (Span-based APIs, incremental hashers, encodings, padding).
- Determining the correct libsodium version and proper initialization.

The audit focused on the wrapper layer: argument validation, lifetime/state management of disposable types, memory zeroing, constant-time considerations, integer overflow checks, and misuse-resistant API patterns.

**Overall verdict:** The library is mature, defensively coded, and follows best practices (libsodium misuse handler, ConstantTime helper, SecureMemory.ZeroMemory marked `NoInlining|NoOptimization`, GuardedHeapAllocation with canary, etc.). Test coverage is extensive, including RFC test vectors, Wycheproof vectors for X25519/Ed25519, tamper tests, and invalid-parameter tests.

**No critical, high-severity, or directly exploitable vulnerabilities were found.** A small number of low-severity issues, hardening opportunities, and minor concerns are listed below with CVSS v3.1 scores.

---

## 2. Methodology

- Manual review of every Geralt `Crypto/`, `Helpers/`, `Validation/`, and `Interop/` source file provided.
- Cross-referenced against the corresponding libsodium documentation contract for buffer lengths, return codes, and side-channel guarantees.
- Reviewed test files to validate intended behavior and edge cases.
- Considered: timing side-channels, memory disclosure, key/nonce reuse risk surfaced by the API, integer overflow, race conditions on disposable types, and resource lifecycle handling (including finalizers).
- Each finding scored with CVSS v3.1 base metrics; vectors are provided.

---

## 3. Findings

### Finding 1 — Length leakage in `ConstantTime.Equals` is unavoidable but documented; lengths-check is a *fast* (non-constant-time) early return

**Location:** `ConstantTime.cs`, `Equals(a, b)`

```csharp
if (a.Length != b.Length) { return false; }
return sodium_memcmp(a, b, (nuint)a.Length) == 0;
```

**Description:** When two inputs of different lengths are compared, the function returns immediately without invoking the constant-time native comparison. This leaks the fact that the lengths differ via timing. The author's own comment acknowledges "It's impossible to prevent the lengths being leaked," which is true for the *length* itself, but a caller passing user-controlled buffers could theoretically learn that lengths mismatch faster than equal-length-but-different-content comparisons.

In practice, all Geralt callers (e.g., `BLAKE2b.VerifyTag`, `IncrementalBLAKE2b.FinalizeAndVerify`, `IncrementalPoly1305.FinalizeAndVerify`) already pre-validate lengths against fixed constants before calling `Equals`, so length-based timing leaks are not exploitable through library APIs. The risk is limited to direct external use of `ConstantTime.Equals`.

**CVSS v3.1:** 2.9 — Low
`CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:N/A:N`
(Network, High complexity — needs precise timing; no privilege; no user interaction; small confidentiality impact: length differential.)

**Remediation:**
- No code change required; behavior is intentional and documented.
- Consider strengthening the XML documentation to explicitly warn callers that they must ensure both inputs have identical, non-secret-dependent lengths before invocation, OR change the implementation to also process a dummy comparison so the timing of "different-length" and "equal-length" paths are similar (a defense-in-depth measure, not a true fix).

---

### Finding 2 — `BLAKE2b.ComputeHash` / `BLAKE2b.DeriveKey` allocate heap arrays for missing salt/personalization on every call

**Location:** `BLAKE2b.cs`

```csharp
salt.Length != 0 ? salt : new byte[SaltSize],
personalization.Length != 0 ? personalization : new byte[PersonalizationSize]
```

**Description:** When the caller omits salt or personalization, a new heap-allocated zero buffer is created and passed to libsodium. While functionally correct (libsodium needs a non-null pointer of the right size, and the zero-filled buffer is semantically equivalent to "no salt/personalization"), this:

1. Creates avoidable heap pressure on hot paths.
2. The zero-filled allocations are not zeroed/cleared after the call. They contain no secret data (just zeros), so no real information disclosure occurs, but it is inconsistent with the rest of the library's careful memory hygiene.

The same pattern is used in `IncrementalBLAKE2b.Reinitialize`.

**CVSS v3.1:** 0.0 — Informational (Not a vulnerability)
`CVSS:3.1/AV:L/AC:H/PR:H/UI:N/S:U/C:N/I:N/A:N`

**Remediation:**
- Use `stackalloc byte[SaltSize]` and `stackalloc byte[PersonalizationSize]` (these are 16 bytes each — perfectly safe to stack-allocate). This removes heap allocations and matches the rest of the library's style.

```csharp
Span<byte> emptySalt = stackalloc byte[SaltSize];
Span<byte> emptyPers = stackalloc byte[PersonalizationSize];
// pass salt.Length != 0 ? salt : emptySalt, etc.
```

---

### Finding 3 — `GuardedHeapAllocation.AsSpan()` releases lock before the Span is used

**Location:** `GuardedHeapAllocation.cs`

```csharp
public unsafe Span<byte> AsSpan()
{
    if (Interlocked.CompareExchange(ref _locked, value: 1, comparand: 0) != 0) { ... }
    try {
        if (_disposed != 0) { throw new ObjectDisposedException(...); }
        return new Span<byte>((void*)_pointer, _size);
    }
    finally {
        Interlocked.Exchange(ref _locked, value: 0);
    }
}
```

**Description:** The lock is acquired, the disposed-check is performed, and a `Span<byte>` is returned. The `finally` block immediately releases the lock **before** the caller has used the span. This means another thread could call `Dispose()`, `NoAccess()`, or `ReadOnly()` concurrently while the first thread is still reading/writing through the returned span — leading to a use-after-free, access violation, or undefined behavior. The lock semantics here protect only the bookkeeping (`_pointer`/`_size`/`_disposed`), not the lifetime of the returned span.

This is largely a TOCTOU/lifetime concern rather than a memory-safety hole in single-threaded use. The class's intended usage model appears to be single-threaded ownership of a `GuardedHeapAllocation` per secret, in which case the issue is moot. However, the locking pattern *suggests* thread-safety guarantees that are not, in fact, provided for the returned span.

**CVSS v3.1:** 3.7 — Low
`CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:L/I:L/A:L`
(Local, requires an unusual concurrent-disposal pattern; could lead to access violation or read of freed memory.)

**Remediation:**
- Document explicitly that `GuardedHeapAllocation` instances are NOT safe to share between threads with concurrent access through the returned `Span<byte>`. The `Interlocked` calls only protect against torn state on the bookkeeping fields, not against the returned span being used after `Dispose`.
- Alternatively, remove the `Interlocked` pattern from `AsSpan()` and rely entirely on documenting single-threaded ownership, since the current pattern provides only a false sense of safety.

---

### Finding 4 — `Argon2id.ComputeHash`/`VerifyHash`/`NeedsRehash` use `char` truncation for ASCII conversion without strict validation in `ComputeHash`

**Location:** `Argon2id.cs`

```csharp
// In VerifyHash / NeedsRehash:
int allAscii = 0;
for (int i = 0; i < hash.Length; i++) {
    hashBytes[i] = (byte)hash[i];   // narrowing cast — loses upper bits
    allAscii |= hash[i] >> 7;
}
ThrowIfInvalidHashFormat(allAscii, hashBytes);
```

**Description:** The narrowing cast `(byte)hash[i]` silently truncates non-ASCII Unicode code points. The subsequent `allAscii` check correctly catches this and throws `FormatException`. This is intentional and well-tested (`InvalidStringTestVectors` covers non-ASCII inputs).

However, the **order of operations** is potentially problematic: the byte buffer is fully populated with truncated values *before* the format check throws. A side-channel-aware attacker could in theory infer that the truncation happened by observing memory state (extremely unrealistic). More practically, this is a defensive code smell — copy-and-validate should happen together, not copy-then-validate.

The remaining function is sound and the libsodium `crypto_pwhash_argon2id_str_verify` is constant-time with respect to the password.

**CVSS v3.1:** 0.0 — Informational
`CVSS:3.1/AV:L/AC:H/PR:H/UI:R/S:U/C:N/I:N/A:N`

**Remediation:** None required. Optionally combine validation and copying into a single pass that aborts early on the first non-ASCII byte to limit attack surface.

---

### Finding 5 — `IncrementalXChaCha20Poly1305` `Rekey()` does not validate the encryption/decryption direction

**Location:** `IncrementalXChaCha20Poly1305.cs`

```csharp
public unsafe void Rekey()
{
    ...
    try {
        if (_disposed != 0) { ... }
        if (_finalized != 0) { ... }
        crypto_secretstream_xchacha20poly1305_rekey(_state);
    }
    ...
}
```

**Description:** `Rekey()` works on both encryption and decryption streams (which is correct usage of libsodium). However, both sides MUST rekey at the *same point* in the stream or decryption will fail. There is no mechanism in Geralt to surface this requirement to the user beyond documentation. The test `Decrypt_MissingRekey` confirms that mismatched rekeying produces a `CryptographicException`, which is the safe failure mode.

This is API design rather than a vulnerability — failure is detected via authentication tag verification, which is the correct behavior.

**CVSS v3.1:** 0.0 — Not a vulnerability (API design observation)

**Remediation:** None required. Consider adding documentation reminding callers that rekey points must match between encryptor and decryptor.

---

### Finding 6 — `SecureRandom.GeneratePassphrase` modulo bias is avoided through `randombytes_uniform`, but wordlist count of 7772 is not a power of two

**Location:** `SecureRandom.cs` / `Resources/wordlist.txt`

**Description:** `SecureRandom.GetInt32` calls libsodium's `randombytes_uniform`, which is documented to be unbiased even for non-power-of-two upper bounds (it uses rejection sampling). So the passphrase generation is **not** vulnerable to modulo bias. This is correct.

The default wordlist contains 7772 words (≈12.92 bits of entropy per word), and a 4-word passphrase yields ~51.7 bits of entropy — sufficient for most use cases but below the 75–80 bit threshold some guidance recommends. This is a usability/policy concern, not a code vulnerability.

**CVSS v3.1:** 0.0 — Not a vulnerability

**Remediation:** Consider raising `MinWordCount` from 4 to 6 (yielding ~77 bits) to align with modern guidance, OR document the entropy implications.

---

### Finding 7 — `Encodings.FromHex` / `FromBase64` pass the `ignoreChars` string into libsodium via `string` marshalling

**Location:** `Encodings.cs`, `Interop.Encodings.cs`

```csharp
int ret = sodium_hex2bin(data, (nuint)data.Length, hexBuffer, (nuint)hexBuffer.Length,
    ignoreChars.ToString(), binaryLength: out _, hexEnd: null);
```

**Description:** The `ignoreChars` `ReadOnlySpan<char>` is converted to a managed `string` (via `.ToString()`), which is then marshalled to UTF-8 for the native call. The resulting heap allocations for the ignored-chars string are not zeroed and not pinned. This is not a security issue because the ignored characters are not secret. However, the `hexBuffer` itself (containing the hex representation) is zeroed in the `finally` block, which is good practice.

There is no real risk here — the hex string itself is not secret (it's an encoding, not a key), but if a caller is hex-encoding secret data (e.g., a key), the input `hex` `ReadOnlySpan<char>` is never zeroed by Geralt. Callers must handle that themselves.

**CVSS v3.1:** 1.8 — Low
`CVSS:3.1/AV:L/AC:H/PR:H/UI:N/S:U/C:L/I:N/A:N`

**Remediation:**
- Document explicitly that callers passing secret data through `Encodings.ToHex`/`FromHex`/`ToBase64`/`FromBase64` must zero their own input/output buffers (the library zeroes only the *intermediate* libsodium buffers).
- This is already the de-facto contract for `Span<byte>` parameters across the library, but explicit documentation would prevent misuse.

---

### Finding 8 — Lack of nonce-misuse resistance enforcement

**Location:** `ChaCha20Poly1305.cs`, `XChaCha20Poly1305.cs`, `AEGIS128L.cs`, `AEGIS256.cs`, etc.

**Description:** All AEAD constructions in Geralt accept caller-provided nonces. Geralt does not provide a built-in safe-nonce generator (e.g., 96-bit random nonce + key-rotation, or a Synthetic IV mode like AES-GCM-SIV). Nonce reuse with ChaCha20-Poly1305 or AEGIS-128L breaks confidentiality and authenticity catastrophically.

This is a property of these primitives, not a bug in Geralt. Geralt's XChaCha20-Poly1305 (192-bit nonce) and AEGIS-256 (256-bit nonce) are sized for random nonce generation safely, mitigating most practical concerns. The library exposes `SecureRandom.Fill` for generating nonces, which is good.

**CVSS v3.1:** N/A — design observation, not a vulnerability

**Remediation:**
- Recommend XChaCha20-Poly1305 or AEGIS-256 as the default for general-purpose AEAD in the public documentation (already implied by the README).
- Optionally, provide a convenience overload that internally generates a random nonce and prepends/returns it alongside the ciphertext.

---

### Finding 9 — `Sodium.Initialize` resets `_initialized` to 0 on failure, allowing repeated init attempts

**Location:** `Sodium.cs`

```csharp
internal static void Initialize()
{
    if (Interlocked.CompareExchange(ref _initialized, value: 1, comparand: 0) != 0) { return; }
    try { Init(); }
    catch {
        Interlocked.Exchange(ref _initialized, 0);
        throw;
    }
}
```

**Description:** On any exception during initialization (e.g., wrong libsodium version, DLL not found), the `_initialized` flag is reset to 0, allowing subsequent calls to retry. This is reasonable behavior for transient errors but allows repeated DLL-loading attempts in tight loops. Not a security issue.

**CVSS v3.1:** 0.0 — Not a vulnerability

**Remediation:** None.

---

### Finding 10 — `ConstantTime.IsAllZeros` does not validate non-empty buffer

**Location:** `ConstantTime.cs`

```csharp
public static bool IsAllZeros(ReadOnlySpan<byte> buffer)
{
    Sodium.Initialize();
    return sodium_is_zero(buffer, (nuint)buffer.Length) == 1;
}
```

**Description:** When called with an empty buffer, `sodium_is_zero` returns 1 (vacuously true). This is libsodium's documented behavior. Used in `Argon2id.ThrowIfInvalidHashFormat`:

```csharp
if (!ConstantTime.IsAllZeros(hashBytes[^1..])) { throw new FormatException(...); }
```

The call slices one byte off the end, so the input is always 1 byte, never empty. Safe in current usage.

**CVSS v3.1:** 0.0 — Not a vulnerability

**Remediation:** None required.

---

### Finding 11 — `IncrementalEd25519ph` does not zero its internal state on `Reinitialize`

**Location:** `IncrementalEd25519ph.cs`

**Description:** Unlike `IncrementalBLAKE2b`, which clears its state buffer on `Dispose`, `IncrementalEd25519ph.Reinitialize` simply calls `crypto_sign_ed25519ph_init` over the existing state buffer without first zeroing it. The native init function presumably overwrites the relevant state, but residual data from a previous signing operation (e.g., partial SHA-512 state) could theoretically remain in unused bytes of the state buffer.

The risk is low because:
- libsodium's init functions fully initialize the state.
- The Ed25519ph state does not include the private key (the key is passed only at `Finalize`).
- `Dispose` does zero the buffer.

**CVSS v3.1:** 1.8 — Low
`CVSS:3.1/AV:L/AC:H/PR:H/UI:N/S:U/C:L/I:N/A:N`

**Remediation:** As a defense-in-depth measure, call `SecureMemory.ZeroMemory(new Span<byte>(_state, crypto_sign_ed25519ph_statebytes))` before `crypto_sign_ed25519ph_init(_state)` in `Reinitialize()`. Apply the same pattern to `IncrementalPoly1305.Reinitialize` and `IncrementalXChaCha20Poly1305.Reinitialize`.

---

### Finding 12 — Finalizers may throw `InvalidOperationException` from `Interlocked` lock check during GC

**Location:** `GuardedHeapAllocation.cs`, `IncrementalBLAKE2b.cs`, `IncrementalEd25519ph.cs`, `IncrementalPoly1305.cs`, `IncrementalXChaCha20Poly1305.cs`

```csharp
private unsafe void Dispose(bool disposing)
{
    if (Interlocked.CompareExchange(ref _locked, value: 1, comparand: 0) != 0) {
        throw new InvalidOperationException("Cannot dispose when another method is locked.");
    }
    ...
}

~IncrementalBLAKE2b() { Dispose(false); }
```

**Description:** If an `IncrementalBLAKE2b` instance is being used by a thread when the GC finalizer runs (which can happen for objects whose owning code path didn't reach `Dispose` due to an exception, with another thread holding the lock), the finalizer will throw. Exceptions thrown from finalizer threads in .NET will crash the process in some hosting scenarios (or be swallowed in others). This is unlikely in practice but is technically a robustness concern.

**CVSS v3.1:** 2.5 — Low
`CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:N/I:N/A:L`

**Remediation:** In the `Dispose(bool disposing)` finalizer path (when `disposing` is `false`), do not check the lock — just free the unmanaged resources directly. Finalizers should never throw. Pattern:

```csharp
private unsafe void Dispose(bool disposing)
{
    if (disposing) {
        if (Interlocked.CompareExchange(ref _locked, 1, 0) != 0) {
            throw new InvalidOperationException(...);
        }
    }
    try {
        if (Interlocked.CompareExchange(ref _disposed, 1, 0) != 0) { return; }
        ... // free unmanaged
    }
    finally {
        if (disposing) Interlocked.Exchange(ref _locked, 0);
    }
}
```

---

## 4. Summary Table

| # | Finding | CVSS v3.1 | Severity |
|---|---------|-----------|----------|
| 1 | Length leakage in `ConstantTime.Equals` | 2.9 | Low |
| 2 | Heap allocations for empty salt/personalization | 0.0 | Informational |
| 3 | `GuardedHeapAllocation.AsSpan` lock semantics | 3.7 | Low |
| 4 | Argon2id ASCII validation ordering | 0.0 | Informational |
| 5 | Rekey direction not verified | 0.0 | Informational |
| 6 | Default wordlist entropy / min word count | 0.0 | Informational |
| 7 | `Encodings` callers must zero own buffers | 1.8 | Low |
| 8 | No built-in nonce-misuse resistance | N/A | Design observation |
| 9 | `Sodium.Initialize` retry behaviour | 0.0 | Informational |
| 10 | `IsAllZeros` empty-buffer semantics | 0.0 | Informational |
| 11 | Incremental state not pre-zeroed on `Reinitialize` | 1.8 | Low |
| 12 | Finalizers may throw under contention | 2.5 | Low |

**No critical, high, or medium severity vulnerabilities were identified.** All findings are low or informational, and most are hardening/documentation improvements rather than exploitable issues.

---

## 5. Positive Findings (defensive coding observed)

The following positive practices were observed and are worth highlighting:

1. **Strict input validation** via the `Validation` helper class on every public method (length, range, nullability).
2. **`SecureMemory.ZeroMemory`** is annotated with `[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]` to prevent the JIT from optimizing the zeroing away — a critical correctness property often missed in cryptographic wrappers.
3. **libsodium's misuse handler is configured** via `sodium_set_misuse_handler` to convert internal panics into managed exceptions.
4. **Exact libsodium version pinning** in `csproj` (`[1.0.22,1.0.23)`) and runtime verification in `Sodium.Init()`.
5. **Counter overflow checks** in `ChaCha20.Encrypt`/`Decrypt` and `XChaCha20.Encrypt`/`Decrypt` prevent silent counter wraparound.
6. **Constant-time tag/hash verification** consistently used (`ConstantTime.Equals` in `BLAKE2b.VerifyTag`, `IncrementalBLAKE2b.FinalizeAndVerify`, `IncrementalPoly1305.FinalizeAndVerify`).
7. **Argon2id PHC string validation** enforces prefix, ASCII, and null-termination checks before passing to libsodium.
8. **HChaCha20 personalization symmetry check** (Cryptanalysis-aware defense, referencing the "Non-random Properties of F" paper).
9. **Comprehensive test suite** including RFC test vectors, Wycheproof vectors for X25519/Ed25519, tamper tests, invalid-parameter tests, and double-dispose tests.
10. **`stackalloc`-based intermediate buffers** for short-lived sensitive data (computed tags/hashes), avoiding heap exposure.
11. **`GuardedHeapAllocation`** offers canary-protected, mlock-able, mprotect-able allocations for long-lived secrets.
12. **`crypto_sign_ed25519_verify_detached` and Wycheproof tests** confirm signature malleability rejection (point 0 / cofactor handling delegated correctly to libsodium).

---

## 6. Remediation Priority

If the maintainer chooses to act, the recommended ordering is:

1. **Finding 12** — Make finalizers exception-safe (small change, robustness improvement).
2. **Finding 3** — Document `GuardedHeapAllocation` thread-safety guarantees clearly.
3. **Finding 11** — Pre-zero incremental state buffers on `Reinitialize` (defense-in-depth).
4. **Finding 2** — Switch empty-salt/personalization buffers to `stackalloc` (consistency/perf).
5. **Findings 1, 7** — Documentation/XML doc improvements.
6. **Finding 6** — Consider raising `MinWordCount`.

---

## 7. Conclusion

Geralt is a **carefully engineered, defensively coded cryptographic wrapper** with no identified critical or exploitable vulnerabilities. The library correctly delegates all primitive operations to the audited libsodium implementation, validates inputs aggressively, manages sensitive memory carefully, and is supported by an extensive test suite including RFC and Wycheproof vectors. The findings above are minor hardening opportunities and documentation suggestions; none represent a meaningful security risk to consumers of the library under typical usage.

The library can be considered **fit for production use** in security-sensitive .NET 8+ applications, provided callers follow the documented contract (especially regarding nonce uniqueness for AEAD constructions and single-threaded ownership of `IDisposable` types).