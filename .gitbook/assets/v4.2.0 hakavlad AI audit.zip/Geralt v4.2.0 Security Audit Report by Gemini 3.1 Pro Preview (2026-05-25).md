# Geralt v4.2.0 Security Audit Report by Gemini 3.1 Pro Preview (2026-05-25)

## Prompt

Conduct a security audit of the Geralt library code.
Assess any discovered vulnerabilities using the Common Vulnerability Scoring System (CVSS).
Propose remediation for identified vulnerabilities, if any.
Provide a detailed report.

---

Here is a detailed security audit report for the Geralt cryptographic library.

## Security Audit Report

### Executive Summary
The Geralt library provides a modern and generally well-structured C# wrapper around the `libsodium` cryptographic library. The API correctly leverages `Span<T>` to minimize memory allocations and enforces strict input validation. However, the audit identified a **Critical** vulnerability regarding the mutation of read-only memory (which can corrupt string literals globally), a **Medium** severity thread-safety issue that can lead to Use-After-Free (UAF) vulnerabilities, and a few lower-severity bugs and architectural concerns.

---

### 1. Critical Vulnerability: Modification of Read-Only Memory in `SecureMemory.ZeroMemory`

**Severity:** Critical
**CVSS v3.1 Score:** 7.5 (High/Critical depending on exploitability context) - `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:H`

**Description:**
In `SecureMemory.cs`, the `ZeroMemory(ReadOnlySpan<char> buffer)` method takes a read-only span, uses the `unsafe` keyword to pin it, and passes the underlying pointer to `sodium_memzero` to overwrite the memory with zeros. 

In C#, a `ReadOnlySpan<char>` can point to immutable memory, such as interned string literals (e.g., `SecureMemory.ZeroMemory("MySecretPassword");`). Because string literals are interned and shared across the entire application domain, modifying one in-place will alter the value of that string globally. Any subsequent use of `"MySecretPassword"` anywhere in the application will yield a string filled with null (`\0`) characters. This breaks the fundamental safety guarantees of the .NET type system and can lead to severe memory corruption, unpredictable application behavior, and potential security bypasses (e.g., overwriting a hardcoded secret key, token, or SQL query string).

**Remediation:**
Remove the `ZeroMemory(ReadOnlySpan<char> buffer)` overload entirely, or change the parameter type to `Span<char>` to ensure that only mutable memory can be passed. Developers should be encouraged to handle sensitive character data using `char[]` or `Span<char>` rather than immutable `string` objects.

---

### 2. Medium Vulnerability: False Sense of Thread Safety Leading to Use-After-Free in `GuardedHeapAllocation`

**Severity:** Medium
**CVSS v3.1 Score:** 5.9 (Medium) - `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:L/A:H`

**Description:**
The `GuardedHeapAllocation` class utilizes `Interlocked.CompareExchange` to implement spin-locks across its methods (e.g., `AsSpan`, `NoAccess`, `Dispose`). This explicitly signals to developers that the class is designed to be thread-safe.

However, in `AsSpan()`, the lock is acquired, the `Span<byte>` pointing to unmanaged memory is created, and the lock is *immediately released* in the `finally` block. If Thread A calls `AsSpan()` and begins reading or writing to the span, Thread B can concurrently call `Dispose()`. Since the lock was already released by Thread A, Thread B will successfully acquire the lock and free the underlying unmanaged memory via `sodium_free`. Thread A will then continue to read/write to the freed memory, resulting in a Use-After-Free (UAF) vulnerability.

**Remediation:**
It is practically impossible to guarantee thread safety for unmanaged memory exposed via `Span<T>` because the span's lifetime cannot be tracked by the parent class. 
1. Remove the locking mechanism (`_locked`) from `GuardedHeapAllocation` and document the class as **not thread-safe**. 
2. Alternatively, implement `IMemoryOwner<byte>` and return `Memory<byte>` using a custom `MemoryManager<byte>` that can track lifetimes and prevent disposal while the memory is actively pinned or in use.

---

### 3. Low Vulnerability / Bug: Null Padding Leakage in `Argon2id.ComputeHash`

**Severity:** Low
**CVSS v3.1 Score:** 3.7 (Low) - `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:N/A:L`

**Description:**
In `Argon2id.cs`, the `ComputeHash` method allocates a 128-byte array (`hashBytes`), clears it, and passes it to `crypto_pwhash_argon2id_str`. Libsodium writes a null-terminated string into this buffer (typically ~97 characters long). 

The method then unconditionally iterates over all 128 bytes and copies them into the output `Span<char> hash`. This means the output span will contain the valid hash string, followed by a null terminator (`\0`), followed by ~30 more null characters. If an application converts this span to a string and stores it in a database, the trailing null characters may cause truncation errors, database exceptions, or string comparison mismatches.

**Remediation:**
Find the actual length of the generated hash string by locating the first null terminator, and only copy the valid characters to the output span. Since the method signature currently does not return the actual length, you may need to add an `out int hashLength` parameter.
```csharp
int length = hashBytes.IndexOf((byte)0);
if (length == -1) length = hashBytes.Length;

for (int i = 0; i < length; i++) {
    hash[i] = (char)hashBytes[i];
}
// Return or expose 'length' to the caller
```

---

### 4. Informational: Undefined Behavior in `Sodium.MisuseHandlerError`

**Severity:** Informational

**Description:**
In `Sodium.cs`, the method `MisuseHandlerError` is decorated with `[UnmanagedCallersOnly]` and is passed to `sodium_set_misuse_handler`. When libsodium encounters a fatal misuse error, it invokes this callback. Currently, the C# callback throws an `InvalidOperationException`.

Throwing a managed exception across an unmanaged boundary (into C code that does not expect it) results in Undefined Behavior and will cause an immediate, ungraceful runtime crash (`FailFast`) in modern .NET. While `sodium_misuse` is designed to abort the process anyway, throwing an exception is an unsafe way to handle it.

**Remediation:**
Instead of throwing an exception, log the fatal error (if possible) and explicitly terminate the process using `Environment.FailFast("libsodium misuse error.");`.

---

### 5. Informational: Unsafe In-Place Overlap in `Spans.Concat`

**Severity:** Informational

**Description:**
In `Spans.cs`, the `Concat` methods copy multiple spans into a destination `buffer`. If a developer passes a slice of the `buffer` as one of the source arguments (e.g., `b`), and `a.CopyTo` overwrites the memory space occupied by `b` before `b` is copied, the data in `b` will be corrupted. `Span.CopyTo` handles overlapping memory safely, but it cannot protect against sequential copies where the first copy overwrites the source of the second.

**Remediation:**
Document that source spans must not overlap with the destination `buffer` unless the operation is strictly safe, or implement overlap detection using `MemoryExtensions.Overlaps`.