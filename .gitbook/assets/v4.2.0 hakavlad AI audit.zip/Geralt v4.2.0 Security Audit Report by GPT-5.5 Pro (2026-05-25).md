# Geralt v4.2.0 Security Audit Report by GPT-5.5 Pro (2026-05-25)

## Prompt

Conduct a security audit of the Geralt library code.
Assess any discovered vulnerabilities using the Common Vulnerability Scoring System (CVSS).
Propose remediation for identified vulnerabilities, if any.
Provide a detailed report.

---

# Security Audit Report: Geralt Library

**Scope:** Static review of the supplied Geralt source files, tests, interop declarations, project metadata, and embedded resources.  
**CVSS version used:** CVSS v3.1 base scores. Because Geralt is a library, several scores are **context-dependent** and should be adjusted for the consuming application’s threat model.

## Executive Summary

Geralt generally follows sound cryptographic practice by delegating primitives to libsodium, validating buffer sizes, using modern algorithms, and covering many functions with well-known test vectors.

However, I identified several security-relevant issues, primarily around **thread-safe initialization**, **safe managed API guarantees**, **native-memory lifetime**, and **format/resource-exhaustion edge cases**. No direct break of the underlying cryptographic primitives was found.

### Highest-priority fixes

1. Make `Sodium.Initialize()` truly blocking/thread-safe.
2. Remove or disable `SecureMemory.ZeroMemory(ReadOnlySpan<char>)`; it can mutate immutable strings.
3. Redesign `GuardedHeapAllocation.AsSpan()` to avoid stale spans/use-after-free from safe C#.
4. Ensure finalizers never throw.
5. Invalidate `IncrementalBLAKE2b` cached state on reinitialization.
6. Harden Argon2id hash parsing against embedded NULs and attacker-controlled work factors.

---

## Findings Summary

| ID | Finding | Severity | CVSS v3.1 |
|---|---|---:|---|
| GRT-SEC-001 | Non-blocking libsodium initialization race | High | 7.0 `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:L/I:L/A:H` |
| GRT-SEC-002 | `SecureMemory.ZeroMemory(ReadOnlySpan<char>)` can corrupt immutable/interned strings | High | 7.1 `CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:H/A:H` |
| GRT-SEC-003 | `GuardedHeapAllocation.AsSpan()` enables safe-code use-after-free / access-violation patterns | High | 7.3 `CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:L/I:H/A:H` |
| GRT-SEC-004 | Finalizers and `Dispose()` paths can throw, risking process termination | Medium | 5.9 `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:N/A:H` |
| GRT-SEC-005 | `IncrementalBLAKE2b` cached state survives `Reinitialize()` | Medium | 5.3 `CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:L/I:H/A:N` |
| GRT-SEC-006 | Argon2id hash strings can contain embedded NUL plus ignored trailing data | Low | 3.7 `CVSS:3.1/AV:N/AC:H/PR:N/UI:N/S:U/C:N/I:L/A:N` |
| GRT-SEC-007 | Argon2id verification may perform unbounded work on attacker-controlled PHC strings | High, conditional | 7.5 `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:H` |

---

## Detailed Findings

## GRT-SEC-001: Non-blocking libsodium initialization race

**Affected file:** `Sodium.cs`

### Issue

`Sodium.Initialize()` sets `_initialized` to `1` before `Init()` completes:

```csharp
if (Interlocked.CompareExchange(ref _initialized, value: 1, comparand: 0) != 0) { return; }
try {
    Init();
}
catch {
    Interlocked.Exchange(ref _initialized, 0);
    throw;
}
```

A second thread entering during the first thread’s `Init()` call will return immediately and proceed to call libsodium before:

- `sodium_init()` has completed,
- the version check has completed,
- the misuse handler has been installed.

### Impact

This creates a race at process startup or first use. In the best case it is harmless; in the worst case it can cause use of libsodium in an unsupported/uninitialized state, version-check bypass during the race window, or process failure.

### Remediation

Use a blocking initialization primitive that only reports success after initialization has completed.

Example:

```csharp
internal static class Sodium
{
    private static readonly object InitLock = new();
    private static bool _initialized;

    internal static void Initialize()
    {
        if (Volatile.Read(ref _initialized)) {
            return;
        }

        lock (InitLock) {
            if (Volatile.Read(ref _initialized)) {
                return;
            }

            Init();
            Volatile.Write(ref _initialized, true);
        }
    }
}
```

Alternatively, use `Lazy<T>` with `LazyThreadSafetyMode.ExecutionAndPublication`.

---

## GRT-SEC-002: `SecureMemory.ZeroMemory(ReadOnlySpan<char>)` can corrupt immutable strings

**Affected file:** `SecureMemory.cs`

### Issue

The library exposes:

```csharp
public static unsafe void ZeroMemory(ReadOnlySpan<char> buffer)
{
    Sodium.Initialize();
    fixed (char* b = buffer) {
        sodium_memzero(new IntPtr(b), (nuint)buffer.Length * sizeof(char));
    }
}
```

Despite accepting a `ReadOnlySpan<char>`, the method writes into it. This allows callers to mutate data that .NET treats as immutable, including strings and interned string literals.

Example of the dangerous pattern:

```csharp
SecureMemory.ZeroMemory("admin".AsSpan());
```

That can corrupt the interned `"admin"` string for the entire process.

The test suite even demonstrates string mutation:

```csharp
ReadOnlySpan<char> s = RandomNumberGenerator.GetString(...).AsSpan();
SecureMemory.ZeroMemory(s);
```

### Impact

This violates .NET memory-safety and immutability expectations. It can cause process-wide data corruption, authorization logic confusion, or denial of service if interned or shared strings are zeroed.

### Remediation

Remove or disable this overload. Only zero mutable buffers.

Recommended API:

```csharp
[MethodImpl(MethodImplOptions.NoInlining | MethodImplOptions.NoOptimization)]
public static unsafe void ZeroMemory(Span<char> buffer)
{
    Sodium.Initialize();
    fixed (char* b = buffer) {
        sodium_memzero(new IntPtr(b), (nuint)buffer.Length * sizeof(char));
    }
}
```

Mark the existing overload obsolete and fail compilation:

```csharp
[Obsolete("Do not zero ReadOnlySpan<char> or string data. Use Span<char> backed by mutable storage.", true)]
public static void ZeroMemory(ReadOnlySpan<char> buffer)
{
    throw new NotSupportedException();
}
```

Also document that secrets should not be stored in `string`.

---

## GRT-SEC-003: `GuardedHeapAllocation.AsSpan()` enables stale-span memory safety violations

**Affected file:** `GuardedHeapAllocation.cs`

### Issue

`AsSpan()` returns a `Span<byte>` over unmanaged guarded memory and then immediately releases the lock:

```csharp
return new Span<byte>((void*)_pointer, _size);
```

After that, the caller can keep using the span while another call changes memory protection or frees the allocation:

```csharp
using var secret = new GuardedHeapAllocation(32);
Span<byte> s = secret.AsSpan();

secret.Dispose();

s[0] = 1; // stale span over freed native memory
```

Similarly, callers can obtain a span and then call `NoAccess()` or `ReadOnly()`, after which the span can cause access violations.

### Impact

This lets safe C# code trigger use-after-free, access violations, and potentially native memory corruption. It undermines the safety normally expected from `Span<T>` APIs.

### Remediation

Do not expose a long-lived span whose lifetime is independent of the allocation/protection state.

Prefer a scoped callback or lease model that holds the lock for the entire access period.

Example design direction:

```csharp
public unsafe void WithReadWriteSpan(Action<Span<byte>> action)
{
    ArgumentNullException.ThrowIfNull(action);

    EnterLock();
    try {
        ThrowIfDisposed();

        int ret = sodium_mprotect_readwrite(_pointer);
        if (ret != 0) {
            throw new InvalidOperationException("Error marking memory as read-write.");
        }

        action(new Span<byte>((void*)_pointer, _size));
    }
    finally {
        if (_pointer != IntPtr.Zero) {
            sodium_mprotect_noaccess(_pointer);
        }

        ExitLock();
    }
}
```

If targeting APIs where `Span<T>` cannot be used with generic delegates, use `System.Buffers.SpanAction<T,TArg>` or a custom delegate.

At minimum:

- Track protection state.
- Throw from `AsSpan()` when memory is not read-write.
- Document that returned spans become invalid after any protection or disposal call.
- Prefer eliminating `AsSpan()` entirely for guarded memory.

---

## GRT-SEC-004: Finalizers and `Dispose()` paths can throw

**Affected files:**

- `GuardedHeapAllocation.cs`
- `IncrementalBLAKE2b.cs`
- `IncrementalEd25519ph.cs`
- `IncrementalPoly1305.cs`
- `IncrementalXChaCha20Poly1305.cs`

### Issue

Finalizers call `Dispose(false)`, but `Dispose(bool)` may throw:

```csharp
if (Interlocked.CompareExchange(ref _locked, value: 1, comparand: 0) != 0) {
    throw new InvalidOperationException("Cannot dispose when another method is locked.");
}
```

An exception escaping a finalizer can terminate the process.

### Impact

A concurrency edge case or GC timing issue can become a denial of service. Public `Dispose()` can also throw instead of being safely idempotent.

### Remediation

Finalizers must never throw. Prefer a `SafeHandle`-based design.

If keeping finalizers, use best-effort cleanup and suppress all finalizer exceptions:

```csharp
~IncrementalBLAKE2b()
{
    try {
        Dispose(false);
    }
    catch {
        // Never throw from a finalizer.
    }
}
```

Better:

- Move native memory ownership into a `SafeHandle`.
- Make `Dispose()` idempotent.
- Avoid throwing from cleanup paths.
- Avoid freeing while another operation can still use the state.

---

## GRT-SEC-005: `IncrementalBLAKE2b` cached state survives `Reinitialize()`

**Affected file:** `IncrementalBLAKE2b.cs`

### Issue

`IncrementalBLAKE2b.Reinitialize()` resets `_finalized` and reinitializes `_state`, but it does not clear `_cachedState` or reset `_cached`.

This means a caller can:

1. Initialize a keyed hash.
2. Cache state.
3. Reinitialize for a different context.
4. Restore the old cached state unexpectedly.

### Impact

This can cause cross-context confusion, accidental reuse of old keyed state, and prolonged retention of secret-derived state in memory.

### Remediation

Invalidate the cached state on every `Reinitialize()`.

Example:

```csharp
private unsafe void ClearCachedState()
{
    if (_cachedState != null) {
        SecureMemory.ZeroMemory(new Span<byte>(_cachedState, crypto_generichash_blake2b_statebytes));
    }

    _cached = 0;
}
```

Call it during reinitialization:

```csharp
public unsafe void Reinitialize(...)
{
    EnterLock();
    try {
        ThrowIfDisposed();

        ClearCachedState();

        // Existing validation and init...
    }
    finally {
        ExitLock();
    }
}
```

Also consider storing `_cachedHashSize` and rejecting restore if the cached state does not match the active hash size.

---

## GRT-SEC-006: Argon2id accepts embedded NUL with ignored trailing data

**Affected file:** `Argon2id.cs`

### Issue

`VerifyHash()` and `NeedsRehash()` copy the provided `ReadOnlySpan<char>` into a zeroed 128-byte buffer and pass it to libsodium’s C-string APIs.

The code checks that the last byte of the fixed buffer is zero:

```csharp
if (!ConstantTime.IsAllZeros(hashBytes[^1..])) {
    throw new FormatException("Invalid password hash string termination.");
}
```

But it does not reject embedded NULs followed by non-NUL characters. Therefore a string like:

```text
$argon2id$...valid-hash...\0attacker-controlled-suffix
```

can be accepted, with libsodium verifying only the part before the first NUL.

### Impact

This can cause hash-string smuggling or canonicalization confusion. It is most relevant when hashes are logged, serialized, compared, or policy-checked outside libsodium.

### Remediation

Define strict NUL handling.

Best option: reject all NUL characters in externally supplied hash strings.

If compatibility with `ComputeHash()`’s fixed 128-character output is required, allow only a trailing all-NUL suffix:

```csharp
private static void ValidateNoEmbeddedNonTrailingNulls(ReadOnlySpan<char> hash)
{
    int firstNull = hash.IndexOf('\0');
    if (firstNull < 0) {
        return;
    }

    for (int i = firstNull; i < hash.Length; i++) {
        if (hash[i] != '\0') {
            throw new FormatException("Invalid password hash string termination.");
        }
    }
}
```

Then pass only the effective pre-NUL hash plus a single terminator to libsodium.

---

## GRT-SEC-007: Argon2id verification may perform unbounded work on attacker-controlled PHC strings

**Affected file:** `Argon2id.cs`

### Issue

`VerifyHash()` accepts a PHC string and lets libsodium use the encoded parameters. There is no application-level cap on memory or iteration count before verification.

If an application verifies attacker-supplied PHC strings directly, an attacker may supply a hash with very large work factors and trigger excessive CPU or memory usage.

### Impact

Conditional denial of service. This is primarily a concern if the hash string itself is attacker-controlled. If hashes only come from trusted storage, the practical risk is much lower.

### Remediation

Provide a capped verification API:

```csharp
public static bool VerifyHash(
    ReadOnlySpan<char> hash,
    ReadOnlySpan<byte> password,
    int maxIterations,
    int maxMemorySize)
{
    // Parse PHC string first.
    // Reject if encoded t or m exceeds policy.
    // Then call libsodium verify.
}
```

Recommendations:

- Parse `m`, `t`, and `p` before calling libsodium.
- Reject `m` above a configured byte/KiB limit.
- Reject `t` above a configured iteration limit.
- Document that `VerifyHash()` should only be used on trusted stored hashes unless caps are enforced.

---

# Additional Hardening Recommendations

## 1. Provide safe Argon2id parameter presets

`Argon2id.MinIterations = 1` and `MinMemorySize = 8192` are libsodium absolute minimums, not production recommendations.

Add constants such as:

```csharp
public const int InteractiveIterations = ...;
public const int InteractiveMemorySize = ...;
public const int SensitiveIterations = ...;
public const int SensitiveMemorySize = ...;
```

Document that minimums are for validation/testing only.

## 2. Document nonce responsibilities prominently

AEAD APIs require caller-supplied nonces. Reusing a nonce with the same key is catastrophic for:

- `ChaCha20Poly1305`
- `XChaCha20Poly1305`, less likely due larger nonce but still must be unique
- `AEGIS128L`
- `AEGIS256`

Consider helper APIs that generate nonces and prepend them to ciphertext.

## 3. Clearly mark raw primitives as advanced

These APIs are easy to misuse:

- `ChaCha20`
- `XChaCha20`
- `Poly1305`
- `X25519.ComputeSharedSecret()`

They should be documented as low-level/advanced. Prefer AEAD and derived shared-key APIs in examples.

## 4. Secretstream consumers must verify final chunks

`IncrementalXChaCha20Poly1305.DecryptChunk()` returns `ChunkFlag`. Applications must check that the stream ends with `ChunkFlag.Final` to detect truncation.

Provide high-level helpers or documentation examples that enforce final-tag verification.

## 5. Check native allocation results explicitly

For classes using `NativeMemory.Alloc()` / `AlignedAlloc()`, explicitly check for null before passing pointers to native functions.

## 6. Avoid throwing from libsodium misuse handler

`Sodium.MisuseHandlerError()` throws from an unmanaged callback. Throwing across unmanaged boundaries is fragile. Prefer `Environment.FailFast()` or allow libsodium’s default abort behavior.

---

# Positive Observations

The codebase has several strong security properties:

- Uses libsodium rather than custom primitive implementations.
- Performs extensive buffer-size validation.
- Uses test vectors from RFCs, drafts, CyberChef, Wycheproof, and libsodium.
- Uses constant-time comparison for tags/hashes where applicable.
- Rejects X25519 low-order public keys via libsodium error handling.
- Zeroes many temporary secret buffers.
- Uses `Span<T>` APIs to reduce avoidable allocations.

---

# Recommended Remediation Order

1. **Fix `Sodium.Initialize()` race.**
2. **Remove `SecureMemory.ZeroMemory(ReadOnlySpan<char>)`.**
3. **Redesign `GuardedHeapAllocation` access/lifetime model.**
4. **Make finalizers non-throwing or migrate native state to `SafeHandle`.**
5. **Invalidate `IncrementalBLAKE2b` cached state during `Reinitialize()`.**
6. **Harden Argon2id NUL handling and add capped verification overloads.**
7. **Update documentation for nonce management, raw primitives, Argon2id parameters, and secretstream final-tag checks.**

Overall, Geralt’s cryptographic primitive selection and test coverage are good, but the native-memory and API-safety issues should be addressed before treating the library as robust in hostile or multi-threaded environments.