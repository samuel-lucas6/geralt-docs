# Geralt v4.1.0 Security Audit Report by GPT-5.5 Pro (2026-05-07)

## Prompt

Conduct a security audit of the Geralt library code.
Assess any discovered vulnerabilities using the Common Vulnerability Scoring System (CVSS).
Propose remediation for identified vulnerabilities, if any.
Provide a detailed report.

---

# Security Audit Report — Geralt Library

**Scope:** Static review of the supplied Geralt source files and tests.  
**CVSS version used:** CVSS v3.1.  
**Important note:** CVSS is imperfect for libraries because exploitability depends heavily on how a consuming application exposes the API. I score findings primarily as *library/API-callable* issues and note where network-exposed use would increase severity.

## Executive Summary

No direct cryptographic break was found in the primary libsodium-backed AEAD, X25519, Ed25519, BLAKE2b, or Argon2id wrappers when used correctly. The test suite includes strong known-answer, tamper, and Wycheproof-style coverage.

However, several security-relevant issues were identified:

| ID | Finding | Severity | CVSS v3.1 |
|---|---|---:|---|
| GRT-001 | Incorrect `sodium_set_misuse_handler` interop signature and unsafe managed exception from unmanaged callback | Medium | 5.5 |
| GRT-002 | Invalid enum values are not rejected before reaching libsodium/native logic | Medium | 5.5 |
| GRT-003 | Native allocations are unchecked and often occur before parameter validation | Low–Medium | 3.3 / context-dependent 5.3 |
| GRT-004 | `SecureMemory.ZeroMemory(ReadOnlySpan<char>)` can mutate immutable/interned strings | Medium | 6.1 |
| GRT-005 | Incremental/stateful APIs are not thread-safe despite partial `Interlocked` usage | Low | 3.6 |
| GRT-006 | Sensitive X25519 temporary buffers are not wiped on exceptional paths | Informational | N/A |
| GRT-007 | Misuse-prone low-level crypto APIs and weak Argon2 minimums need stronger guidance/defaults | Informational | N/A |

---

## Positive Security Observations

The code has several good security properties:

- AEAD wrappers validate key, nonce, tag, plaintext, and ciphertext sizes before native calls.
- Decryption failure paths are tested to ensure tampered inputs fail.
- X25519 low-order public keys are rejected through libsodium return-code checks.
- Ed25519 verification is tested against invalid/malleability vectors.
- Constant-time comparison uses `sodium_memcmp`.
- Sensitive computed tags/hashes are zeroed in several places.
- libsodium version is pinned and checked at runtime.
- Guarded heap allocations use libsodium’s guarded memory APIs.

---

# Detailed Findings

## GRT-001 — Incorrect `sodium_set_misuse_handler` Interop Signature and Unsafe Callback Behavior

**Affected files:**

- `Interop.Sodium.cs`
- `Sodium.cs`

### Issue

The interop declaration is:

```csharp
internal static unsafe partial int sodium_set_misuse_handler(delegate* unmanaged[Cdecl]<void> handler);
```

But libsodium’s `sodium_set_misuse_handler()` returns `void`, not `int`. The managed wrapper then checks the return value:

```csharp
if (sodium_set_misuse_handler(&MisuseHandlerError) != 0) {
    throw new InvalidOperationException("Unable to set libsodium misuse handler.");
}
```

If the native function returns `void`, reading a return value is ABI-incorrect and can result in unpredictable behavior, including false initialization failures.

Additionally, the unmanaged callback throws a managed exception:

```csharp
[UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
private static void MisuseHandlerError()
{
    throw new InvalidOperationException("libsodium misuse error. Please create a bug issue on GitHub.");
}
```

Throwing a managed exception across an unmanaged callback boundary is unsafe and may terminate the process or produce undefined behavior. libsodium misuse handlers are effectively no-return fatal handlers.

### Impact

A libsodium misuse event, or potentially an ABI return-value mismatch during initialization, can cause process termination or unpredictable initialization failure.

### CVSS

**CVSS v3.1:** `CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H`  
**Score:** 5.5 Medium

If Geralt is used inside a network service and a remote request can trigger first use or a misuse path, availability impact may be higher.

### Remediation

Correct the P/Invoke signature and avoid throwing from the unmanaged callback.

```csharp
[LibraryImport(DllName)]
[UnmanagedCallConv(CallConvs = [typeof(CallConvCdecl)])]
internal static unsafe partial void sodium_set_misuse_handler(
    delegate* unmanaged[Cdecl]<void> handler);
```

Then:

```csharp
sodium_set_misuse_handler(&MisuseHandlerFailFast);
```

Use a fail-fast handler:

```csharp
[UnmanagedCallersOnly(CallConvs = [typeof(CallConvCdecl)])]
private static void MisuseHandlerFailFast()
{
    Environment.FailFast("libsodium misuse detected.");
}
```

Also make all libsodium misuse conditions unreachable through managed validation.

---

## GRT-002 — Invalid Enum Values Are Not Rejected

**Affected files:**

- `Encodings.cs`
- `IncrementalXChaCha20Poly1305.cs`

### Issue

C# enums are not value-restricted at runtime. Callers can pass arbitrary values:

```csharp
Encodings.ToBase64(buffer, data, (Encodings.Base64Variant)999);
```

or:

```csharp
secretstream.EncryptChunk(c, p, (IncrementalXChaCha20Poly1305.ChunkFlag)255);
```

`Base64Variant` is passed to libsodium:

```csharp
sodium_base64_encoded_len((nuint)data.Length, (int)variant)
sodium_bin2base64(..., (int)variant)
sodium_base642bin(..., (int)variant)
```

Invalid libsodium base64 variants may trigger `sodium_misuse()`, which is fatal. This risk is amplified by GRT-001.

`ChunkFlag` is cast directly to `byte` and passed to secretstream. Even if libsodium accepts arbitrary tag bytes, returning undefined enum values can cause protocol confusion in consuming applications.

### Impact

An invalid enum can cause denial of service or authenticated-but-unknown stream chunk flags.

### CVSS

**CVSS v3.1:** `CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:H`  
**Score:** 5.5 Medium

If a network API directly exposes these options to unauthenticated users, a deployment-specific score could be `AV:N/PR:N`, approximately **7.5 High**.

### Remediation

Validate enum values before native calls.

```csharp
private static void ValidateBase64Variant(Encodings.Base64Variant variant)
{
    if (variant is not (
        Encodings.Base64Variant.Original or
        Encodings.Base64Variant.OriginalNoPadding or
        Encodings.Base64Variant.Url or
        Encodings.Base64Variant.UrlNoPadding)) {
        throw new ArgumentOutOfRangeException(nameof(variant), variant, "Invalid Base64 variant.");
    }
}
```

Call this in:

- `ToBase64`
- `GetToBase64BufferSize`
- `FromBase64`
- `GetFromBase64BufferSize`

For secretstream:

```csharp
private static void ValidateChunkFlag(ChunkFlag chunkFlag)
{
    if (chunkFlag is not (
        ChunkFlag.Message or
        ChunkFlag.Boundary or
        ChunkFlag.Rekey or
        ChunkFlag.Final)) {
        throw new ArgumentOutOfRangeException(nameof(chunkFlag), chunkFlag, "Invalid chunk flag.");
    }
}
```

Also reject unknown decrypted flags defensively.

---

## GRT-003 — Native Allocations Are Unchecked and Often Happen Before Validation

**Affected files:**

- `IncrementalBLAKE2b.cs`
- `IncrementalPoly1305.cs`
- `IncrementalEd25519ph.cs`
- `IncrementalXChaCha20Poly1305.cs`
- partially `GuardedHeapAllocation.cs`

### Issue

Several constructors allocate unmanaged memory before validating all caller-controlled parameters:

```csharp
_state = NativeMemory.AlignedAlloc(...);
_cachedState = NativeMemory.AlignedAlloc(...);
Reinitialize(hashSize, key, personalization, salt);
```

If `Reinitialize()` throws due to invalid parameters, unmanaged memory has already been allocated. Finalizers may eventually release it, but this can create unmanaged memory pressure and denial-of-service risk.

Allocations are also not checked for `null`. If native allocation fails, subsequent native calls can receive a null state pointer.

### Impact

- Repeated invalid constructions can create memory-pressure DoS.
- Low-memory situations can lead to process crash rather than controlled `InsufficientMemoryException`.

### CVSS

For local/API-callable context:

**CVSS v3.1:** `CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:N/A:L`  
**Score:** 3.3 Low

If exposed to unauthenticated network input in a service:

**CVSS v3.1:** `CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L`  
**Score:** 5.3 Medium

### Remediation

Validate parameters before allocation, check allocation results, and free on constructor failure.

Example pattern:

```csharp
public unsafe IncrementalPoly1305(ReadOnlySpan<byte> oneTimeKey)
{
    Validation.EqualTo($"{nameof(oneTimeKey)}.{nameof(oneTimeKey.Length)}",
        oneTimeKey.Length, KeySize);

    Sodium.Initialize();

    _state = NativeMemory.AlignedAlloc(
        crypto_onetimeauth_poly1305_statebytes,
        crypto_onetimeauth_poly1305_statebytes_CRYPTO_ALIGN);

    if (_state == null) {
        throw new InsufficientMemoryException("Insufficient memory for Poly1305 state.");
    }

    try {
        Reinitialize(oneTimeKey);
    }
    catch {
        Dispose();
        throw;
    }
}
```

Also consider `GC.AddMemoryPressure()` / `GC.RemoveMemoryPressure()` for unmanaged state.

For `GuardedHeapAllocation.Dispose()` add a null-pointer guard:

```csharp
if (_pointer != IntPtr.Zero) {
    sodium_free(_pointer);
    _pointer = IntPtr.Zero;
}
```

---

## GRT-004 — `SecureMemory.ZeroMemory(ReadOnlySpan<char>)` Can Mutate Immutable Strings

**Affected file:**

- `SecureMemory.cs`
- test confirms behavior in `SecureMemoryTests.cs`

### Issue

The library exposes:

```csharp
public static unsafe void ZeroMemory(ReadOnlySpan<char> buffer)
```

It pins and overwrites the supplied memory:

```csharp
fixed (char* b = buffer) {
    sodium_memzero(new IntPtr(b), (nuint)buffer.Length * sizeof(char));
}
```

Because `ReadOnlySpan<char>` can point to a `string`, this allows mutation of immutable string storage. The test suite explicitly verifies string mutation:

```csharp
ReadOnlySpan<char> s = RandomNumberGenerator.GetString(...).AsSpan();
SecureMemory.ZeroMemory(s);
```

This is dangerous because interned string literals or shared string instances can be corrupted process-wide.

### Impact

Possible integrity and availability problems inside the consuming process, including corruption of constants, dictionary keys, security labels, or configuration strings.

### CVSS

**CVSS v3.1:** `CVSS:3.1/AV:L/AC:L/PR:L/UI:N/S:U/C:N/I:H/A:L`  
**Score:** 6.1 Medium

### Remediation

Do not accept `ReadOnlySpan<char>` for destructive operations. Replace with a mutable span overload:

```csharp
public static unsafe void ZeroMemory(Span<char> buffer)
{
    Sodium.Initialize();
    fixed (char* b = buffer) {
        sodium_memzero(new IntPtr(b), (nuint)buffer.Length * sizeof(char));
    }
}
```

Avoid supporting string zeroization. Document that secrets should not be stored in immutable `string` objects. Recommend:

- `Span<char>`
- `char[]`
- `Span<byte>`
- `GuardedHeapAllocation`

If backward compatibility is needed, mark the `ReadOnlySpan<char>` overload obsolete and make it throw.

---

## GRT-005 — Incremental APIs Are Not Thread-Safe

**Affected files:**

- `IncrementalBLAKE2b.cs`
- `IncrementalPoly1305.cs`
- `IncrementalEd25519ph.cs`
- `IncrementalXChaCha20Poly1305.cs`
- `GuardedHeapAllocation.cs`

### Issue

The stateful classes use `Interlocked.CompareExchange()` mostly as a read check:

```csharp
if (Interlocked.CompareExchange(ref _finalized, value: 1, comparand: 1) != 0) {
    throw new InvalidOperationException(...);
}
```

This checks whether `_finalized == 1`, but it does not atomically transition the object into a finalizing state. Two threads can pass the check simultaneously and both operate on the same native state.

`Dispose()` can also race with `Update()`, `Finalize()`, or `AsSpan()`.

### Impact

Concurrent use can cause:

- double finalization,
- invalid MAC/hash/signature results,
- native-state corruption,
- process crashes.

### CVSS

**CVSS v3.1:** `CVSS:3.1/AV:L/AC:H/PR:L/UI:N/S:U/C:N/I:L/A:L`  
**Score:** 3.6 Low

If a shared instance is used across unauthenticated network requests, deployment impact may be higher.

### Remediation

Either clearly document all stateful types as **not thread-safe**, or enforce synchronization.

Simplest robust approach:

```csharp
private readonly object _sync = new();

public void Update(ReadOnlySpan<byte> message)
{
    lock (_sync) {
        ThrowIfDisposed();
        if (_finalized != 0) {
            throw new InvalidOperationException("Cannot update after finalizing.");
        }

        int ret = crypto_generichash_blake2b_update(_state, message, (ulong)message.Length);
        if (ret != 0) {
            throw new CryptographicException("Error updating hash function state.");
        }
    }
}
```

For finalization, atomically mark finalized before native finalization:

```csharp
if (Interlocked.CompareExchange(ref _finalized, 1, 0) != 0) {
    throw new InvalidOperationException("Cannot finalize twice.");
}
```

But locking is easier and safer because `Update()`, `Finalize()`, `Reinitialize()`, and `Dispose()` all need mutual exclusion.

---

## GRT-006 — X25519 Temporary Secrets Are Not Wiped on Exceptional Paths

**Affected file:**

- `X25519.cs`

### Issue

Temporary buffers are zeroed only at the end of `DeriveSharedKey()`:

```csharp
SecureMemory.ZeroMemory(sharedSecret);
SecureMemory.ZeroMemory(yourPublicKey);
```

If an exception occurs before those lines, `sharedSecret` can remain in stack memory longer than necessary.

### Impact

Low practical exploitability in managed code, but this weakens secret hygiene.

### CVSS

Not scored. This is a hardening issue rather than a directly exploitable vulnerability.

### Remediation

Use `try/finally`:

```csharp
private static void DeriveSharedKey(...)
{
    Span<byte> sharedSecret = stackalloc byte[SharedSecretSize];
    Span<byte> yourPublicKey = stackalloc byte[PublicKeySize];

    try {
        ComputeSharedSecret(sharedSecret, yourPrivateKey, othersPublicKey);
        ComputePublicKey(yourPublicKey, yourPrivateKey);

        using var blake2b = new IncrementalBLAKE2b(sharedKey.Length, preSharedKey, personalization);
        blake2b.Update(sharedSecret);
        blake2b.Update(isSender ? yourPublicKey : othersPublicKey);
        blake2b.Update(isSender ? othersPublicKey : yourPublicKey);
        blake2b.Finalize(sharedKey);
    }
    finally {
        SecureMemory.ZeroMemory(sharedSecret);
        SecureMemory.ZeroMemory(yourPublicKey);
    }
}
```

---

## GRT-007 — Misuse-Prone APIs and Weak Parameter Floors

**Affected files:**

- `Argon2id.cs`
- `ChaCha20.cs`
- `XChaCha20.cs`
- `Poly1305.cs`
- `HChaCha20.cs`
- `IncrementalXChaCha20Poly1305.cs`

### Issue

These are not direct implementation vulnerabilities, but they are important misuse risks:

1. `Argon2id.MinIterations = 1` and `Argon2id.MinMemorySize = 8192` are libsodium minimums, not recommended password-hashing parameters.
2. Raw `ChaCha20` / `XChaCha20` encryption is unauthenticated and malleable.
3. Raw `Poly1305` requires strict one-time key usage.
4. Secretstream decryption requires callers to enforce receipt of a `Final` chunk; otherwise truncation may be missed at the application layer.
5. Nonce uniqueness is fully caller-managed for AEAD and stream-cipher APIs.

### CVSS

Not scored as library vulnerabilities because exploitation depends on consuming-application misuse.

### Remediation

Add explicit recommended constants and safer overloads.

For Argon2id:

```csharp
public const int InteractiveIterations = crypto_pwhash_argon2id_OPSLIMIT_INTERACTIVE;
public const int InteractiveMemorySize = crypto_pwhash_argon2id_MEMLIMIT_INTERACTIVE;
public const int ModerateIterations = crypto_pwhash_argon2id_OPSLIMIT_MODERATE;
public const int ModerateMemorySize = crypto_pwhash_argon2id_MEMLIMIT_MODERATE;
public const int SensitiveIterations = crypto_pwhash_argon2id_OPSLIMIT_SENSITIVE;
public const int SensitiveMemorySize = crypto_pwhash_argon2id_MEMLIMIT_SENSITIVE;
```

Also consider overloads with safe defaults:

```csharp
public static void ComputeHash(Span<char> hash, ReadOnlySpan<byte> password)
{
    ComputeHash(hash, password, InteractiveIterations, InteractiveMemorySize);
}
```

For low-level crypto primitives:

- Move unauthenticated primitives into a `LowLevel` or `Advanced` namespace.
- Add XML documentation warning that `ChaCha20` / `XChaCha20` do **not** authenticate ciphertext.
- Prefer `ChaCha20Poly1305`, `XChaCha20Poly1305`, `AEGIS128L`, or `AEGIS256` for encryption.
- Document Poly1305 one-time key requirements prominently.
- Provide nonce-generation helpers or higher-level nonce-managed APIs.

---

# Additional Hardening Recommendations

## 1. Add Native Allocation Failure Tests

Abstract unmanaged allocation behind an internal allocator so tests can simulate failure. Verify constructors throw `InsufficientMemoryException` and do not leak memory.

## 2. Add Invalid Enum Tests

Add tests for:

```csharp
(Encodings.Base64Variant)0
(Encodings.Base64Variant)999
(IncrementalXChaCha20Poly1305.ChunkFlag)255
```

Expected result: managed `ArgumentOutOfRangeException`, never process abort.

## 3. Add Concurrency Tests

Stress shared instances with concurrent:

- `Update()`
- `Finalize()`
- `Reinitialize()`
- `Dispose()`

If thread-safety is not intended, document that explicitly.

## 4. Use Pure Managed Base64 Length Calculation

`Encodings.GetToBase64BufferSize()` currently calls libsodium before `Sodium.Initialize()`. Prefer managed length calculation or initialize first.

## 5. Improve Documentation Around Nonce Reuse

Every nonce-based encryption API should state:

- same key + nonce reuse is catastrophic,
- nonces should be random or monotonically unique as appropriate,
- XChaCha20-Poly1305 is preferred when random nonce generation is desired.

---

# Overall Conclusion

Geralt’s core cryptographic wrapping is generally sound and benefits from libsodium. The main issues are not algorithmic breaks, but API/interop safety problems:

1. Fix the libsodium misuse-handler interop and callback behavior.
2. Validate all enum values before native calls.
3. Validate before unmanaged allocation and check allocation failure.
4. Remove or deprecate destructive `ReadOnlySpan<char>` zeroization.
5. Clarify or enforce thread-safety for incremental objects.

Addressing these would substantially improve robustness and reduce denial-of-service and misuse risk.