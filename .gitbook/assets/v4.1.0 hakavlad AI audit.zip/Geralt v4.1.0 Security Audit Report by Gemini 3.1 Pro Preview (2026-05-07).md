# Geralt v4.1.0 Security Audit Report by Gemini 3.1 Pro Preview (2026-05-07)

## Prompt

Conduct a security audit of the Geralt library code.
Assess any discovered vulnerabilities using the Common Vulnerability Scoring System (CVSS).
Propose remediation for identified vulnerabilities, if any.
Provide a detailed report.

---

Here is a detailed security audit report for the `Geralt` cryptographic library based on the provided source code.

## Executive Summary
Geralt is a modern, high-performance cryptographic library for .NET wrapping `libsodium`. The code is generally well-structured, utilizing modern .NET features like `Span<T>` and `ReadOnlySpan<T>` to avoid unnecessary allocations, and correctly performing boundary validations before interacting with unmanaged code. 

However, the audit identified **one high-severity vulnerability** related to memory corruption of immutable strings, and **one low-severity vulnerability** regarding thread-safety during the library's initialization. A few informational findings were also identified to improve the library's robustness.

---

## 1. Vulnerabilities

### 1.1 Memory Corruption via `SecureMemory.ZeroMemory(ReadOnlySpan<char>)`
**Severity:** High
**CVSS v3.1 Score:** 7.1 (AV:L/AC:L/PR:N/UI:N/S:U/C:N/I:H/A:H)

**Description:**
In `SecureMemory.cs`, there is an overload for `ZeroMemory` that accepts a `ReadOnlySpan<char>`:
```csharp
public static unsafe void ZeroMemory(ReadOnlySpan<char> buffer)
{
    Sodium.Initialize();
    fixed (char* b = buffer) {
        sodium_memzero(new IntPtr(b), (nuint)buffer.Length * sizeof(char));
    }
}
```
In .NET, the `string` type has an implicit conversion to `ReadOnlySpan<char>`. Because strings are immutable and often interned (shared globally within the application domain), passing a string literal (e.g., `SecureMemory.ZeroMemory("mySecretPassword")`) will successfully compile but will overwrite the interned string in memory with null characters. This breaks the fundamental immutability contract of .NET strings and corrupts the application state globally. Any subsequent use of that string literal elsewhere in the application will yield null characters, potentially leading to logic bypasses or application crashes (Denial of Service).

**Remediation:**
Change the parameter type from `ReadOnlySpan<char>` to `Span<char>`. `Span<T>` strictly enforces mutability at compile time and prevents developers from implicitly passing immutable `string` objects.
```csharp
public static unsafe void ZeroMemory(Span<char> buffer)
```

---

### 1.2 Race Condition in `Sodium.Initialize()`
**Severity:** Low
**CVSS v3.1 Score:** 3.3 (AV:L/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L)

**Description:**
In `Sodium.cs`, the initialization uses a flawed pattern for double-checked locking:
```csharp
private static int _initialized;

internal static void Initialize()
{
    if (Interlocked.CompareExchange(ref _initialized, value: 1, comparand: 1) != 1) {
        Init();
    }
}
```
If multiple threads invoke a cryptographic function simultaneously for the first time, `_initialized` will be `0`. Both threads will bypass the `Interlocked` check and enter `Init()` concurrently.

Inside `Init()`, `sodium_set_misuse_handler(&MisuseHandlerError)` is called. According to `libsodium` documentation, `sodium_set_misuse_handler` modifies a global function pointer and is **not thread-safe**. Calling it concurrently introduces a data race in unmanaged code, which can result in undefined behavior or a crash during startup.

**Remediation:**
Use standard C# thread-safety primitives (like `lock` or `Lazy<T>`) to ensure `Init()` is executed exactly once without race conditions.
```csharp
private static int _initialized;
private static readonly object _initLock = new object();

internal static void Initialize()
{
    if (Volatile.Read(ref _initialized) == 1) return;
    lock (_initLock) {
        if (Volatile.Read(ref _initialized) == 1) return;
        Init();
        Volatile.Write(ref _initialized, 1);
    }
}
```
*(Note: Ensure `Interlocked.Exchange` is removed from inside `Init()` if you use this lock pattern).*

---

## 2. Informational Findings & Best Practices

### 2.1 Exception Propagation from `[UnmanagedCallersOnly]`
In `Sodium.cs`, the `MisuseHandlerError` method is marked with `[UnmanagedCallersOnly]` and throws an `InvalidOperationException`.
In modern .NET, throwing an exception that escapes an `[UnmanagedCallersOnly]` method is undefined behavior and strictly causes a `FailFast` (immediate process crash). Since Libsodium's misuse handler is expected to abort the process anyway, this achieves the desired result. However, explicitly calling `Environment.FailFast()` is a cleaner and safer approach to signal process termination to the runtime.

### 2.2 Trailing Null Characters in Argon2id Hashes
In `Argon2id.cs`, `ComputeHash` requires the user to pass a `Span<char>` of exactly `HashSize` (128 characters). The `crypto_pwhash_argon2id_str` function writes a null-terminated string (usually ~97 characters long) into the buffer. The loop then directly copies all 128 bytes into the `char` span:
```csharp
for (int i = 0; i < hashBytes.Length; i++) {
    hash[i] = (char)hashBytes[i];
}
```
If a developer converts this `Span<char>` directly to a `string`, it will contain ~31 trailing `\0` characters. While `VerifyHash` handles this gracefully, storing strings with trailing nulls in databases can cause truncation or comparison issues.
**Recommendation:** Use `MemoryExtensions.IndexOf(hashBytes, (byte)0)` to find the string's actual length and only copy the characters up to the null terminator.

### 2.3 Use-After-Free Risk with `GuardedHeapAllocation`
`GuardedHeapAllocation` provides an `AsSpan()` method that returns a `Span<byte>` over unmanaged memory. If a developer holds onto this `Span` and the `GuardedHeapAllocation` is disposed (e.g., exiting a `using` block), the `Span` will point to freed memory, leading to a Use-After-Free (UAF) vulnerability if accessed.<br>
**Recommendation:** While this is a well-known risk of using `Span<T>` over unmanaged memory, thorough documentation should be added explicitly warning users never to let the `Span<byte>` outlive the `GuardedHeapAllocation` instance. Alternatively, consider implementing a custom `MemoryManager<byte>` to safely wrap the unmanaged memory.

### 2.4 Lack of Thread-Safety in Stateful Incremental Classes
Classes like `IncrementalXChaCha20Poly1305` and `IncrementalBLAKE2b` maintain internal unmanaged state pointers (`_state`). While they use `Interlocked` checks to track the `_disposed` and `_finalized` statuses, the actual cryptographic operations (e.g., `EncryptChunk`) are not locked. If invoked concurrently from multiple threads, it will cause severe memory corruption in unmanaged code.<br>
**Recommendation:** It is standard in .NET that instance members are not thread-safe, but the usage of `Interlocked` checks might give developers a false sense of thread-safety. Document clearly that these incremental classes are **not thread-safe** and require external synchronization if shared across threads.




